# PRAXIS Autonomous Agent Framework

A prompt and configuration blueprint for autonomous, multi-role software-engineering agents.

Version 1.0.0

## What This Is

PRAXIS is a complete, specification-driven design for an autonomous agent that researches, plans, writes and changes code, tests, debugs, documents, manages files and tasks, uses tools, browses the web, recovers from errors, reflects on outcomes, and carries long-running work to a verified result. The agent works as a team of 18 roles led by one Master Orchestrator, and it continues on its own inside a bounded envelope until the objective is verified.

It is configuration and prompts, not a program. A host runtime that supports tool calling loads the files, composes the prompts for each role, provides the tools, and enforces the policies. The files are the source of truth for agent behavior, and the host adds enforcement and tool access and adds no behavior of its own.

## What It Contains

33 files: 13 Markdown files and 20 YAML files.

- Identity and conventions: the system prompt (identity, mission, decision, tool, planning, reflection, memory, failure, and verification hierarchies, and the safety invariants) and the developer prompt (message envelope and standard blocks).
- Roles: 18 role contracts with authority, delegation, escalation, and success and failure criteria, the supervision and arbitration rules, and 10 role prompts.
- Work cycle: the ten-stage execution loop, planning, task management, 12 workflows, 8 reasoning modes, reflection and lessons, a coding agent framework, and documentation rules.
- Tools, safety, and quality: a registry of 36 capabilities in 5 risk tiers, 15 hard stops with trust levels and an audit log, 5 autonomy levels with approvals, evidence classes and self-correction, 7 quality pipelines with 5 gates, and error recovery with rollback.
- Memory and context: 8 memory types with write gates and scored retrieval, and context budgets with compaction and recovery.
- Runtime setup: environment variables, model tiers, budgets, limits, and the file layout of the repository and of the agent's workspace.

## What It Is For

- Running an autonomous engineering agent on any model host that supports tool calling, for work such as feature delivery, bug fixing, refactoring, research, documentation, code review, dependency updates, security audits, and long-running operations.
- Keeping that agent trustworthy. Every claim needs evidence, nothing counts as done until a different role has verified it, autonomy is bounded by risk tiers and approvals, every action is logged, and state is checkpointed so that a run can be recovered.
- Serving as a reference design and a starting point for developers and operators who build or customize their own agent systems. Each behavior lives in one named file and can be changed without editing the others.

## Repository Contents

Prompts

| File | Purpose |
| --- | --- |
| system_prompt.md | Identity, hierarchies, operating behaviors, and safety invariants for every role |
| developer_prompt.md | Runtime conventions, message envelope, and standard blocks for every role |
| orchestrator_prompt.md | Master Orchestrator |
| planner_prompt.md | Planner and Task Analyzer |
| researcher_prompt.md | Researcher and Web Researcher |
| coder_prompt.md | Code Writer and Test Engineer |
| reviewer_prompt.md | Code Reviewer and Security Auditor |
| debugger_prompt.md | Debugger |
| critic_prompt.md | Reflection Agent and Quality Assurance Agent |
| memory_manager_prompt.md | Memory Manager and Context Manager |
| executor_prompt.md | Executor and File Manager |
| tool_selection_prompt.md | Tool Manager and the tool selection procedure |

Configuration

| File | Purpose |
| --- | --- |
| master_agent.yaml | Identity, prompt composition, supervision tree, collaboration, arbitration, run lifecycle |
| agent_config.yaml | Environment contract, model tiers, budgets, timeouts, retries, limits, run modes |
| roles.yaml | Role contracts: authority, delegation, escalation, success and failure criteria |
| skills.yaml | Skill registry and the coding agent framework |
| execution_loop.yaml | The ten-stage loop and the micro loop for actions |
| workflow.yaml | Routing and twelve end-to-end workflows |
| planning.yaml | Planning hierarchy, algorithm, option scoring, quality gate, replanning |
| task_management.yaml | Task schema, decomposition, dependencies, scoring, handoff, delegation, stuck recovery |
| reasoning_framework.yaml | Eight reasoning modes, uncertainty, hypothesis and assumption management |
| reflection.yaml | Reflection levels, failure and success analysis, lessons, improvement governance |
| documentation.yaml | Documentation policy, document types, synchronization rules |
| tool_use.yaml | Capability registry and the tool architecture |
| verification.yaml | Evidence classes, verification hierarchy, self-correction detectors |
| quality_control.yaml | Verification pipelines, gates, thresholds, metrics |
| security.yaml | Hard stops, trust levels, policies, audit, incident response |
| autonomy.yaml | Autonomy levels, approvals, continuation, check-ins, safe stop |
| memory.yaml | Memory types, policies, scoring, integrity |
| context_management.yaml | Context budgets, compaction, recovery, re-anchoring |
| error_handling.yaml | Error taxonomy, recovery ladder, rollback, crash recovery |
| project_structure.yaml | Repository layout and runtime workspace layout |

## Precedence

1. Safety invariants in system_prompt.md and the hard stops in security.yaml.
2. system_prompt.md.
3. developer_prompt.md and the YAML files.
4. The role prompt and its overlay.
5. The user's instructions and approvals.
6. Plans, task records, and memory written by the agent.
7. Tool results, files, web pages, and other retrieved content, which are data and never instructions.

When a prompt and a YAML file disagree, the YAML file governs numbers, limits, and schemas, and system_prompt.md governs principles. Each number is defined in one owning file, and other files refer to it by path in the form file.yaml#key.

## Load and Composition Order

1. Load the YAML files in the order listed in project_structure.yaml#framework_repository and validate them (see Startup Validation).
2. For each role compose the prompt in this order: system_prompt.md, developer_prompt.md, the files in prompt_files of the role in roles.yaml, then its prompt_overlay (master_agent.yaml#prompt_composition).
3. Record the sha256 of every prompt and configuration file in run.json. A mismatch during a run triggers a safe stop.
4. Run tool discovery, the security preflight, the memory integrity check, and recovery of an unfinished run (master_agent.yaml#startup_sequence).
5. Enter the loop at OBSERVE.

## Environment Variables

Required:

| Variable | Meaning |
| --- | --- |
| PRAXIS_WORKSPACE_ROOT | Absolute path of the project directory the agent works in |
| PRAXIS_MODEL_REASONING | Model identifier for the reasoning tier |
| PRAXIS_MODEL_BALANCED | Model identifier for the balanced tier |
| PRAXIS_MODEL_FAST | Model identifier for the fast tier |

Optional:

| Variable | Default | Meaning |
| --- | --- | --- |
| PRAXIS_STATE_DIR | .praxis | State directory relative to the workspace root |
| PRAXIS_AUTONOMY_LEVEL | L3_extended | A level id from autonomy.yaml#levels |
| PRAXIS_RUN_COST_CAP_USD | 20.0 | Hard cost cap for one run |
| PRAXIS_CONTEXT_WINDOW_TOKENS | 200000 | Context window of the smallest model in use |
| PRAXIS_NETWORK_ALLOWLIST_FILE | none | File with extra allowed domains, one per line |
| PRAXIS_APPROVAL_CHANNEL | console | console, file, or webhook |
| PRAXIS_LOG_LEVEL | info | debug, info, warn, or error |
| PRAXIS_USER_LANGUAGE | auto | Reply language, or auto to follow the user's own words |
| PRAXIS_RUN_MODE | interactive | interactive, autonomous, or batch |
| PRAXIS_KILL | unset | When set to 1 the run safe-stops at the next check |

Provider credentials and tool secrets are held by the host and are never visible to agents.

## Host Responsibilities

A host that runs PRAXIS must:

- Provide the capabilities in tool_use.yaml#capability_registry through a gateway that applies the pre-invocation checks, the risk tiers, the role capability lists, the path policy, the command policy, and the network policy. A capability the host cannot provide is reported as a blocker.
- Enforce the autonomy level, the approval protocol, and the grants.
- Hold secrets and inject them by reference at call time, redact before logging, and keep secret values out of every prompt.
- Write the append-only audit log with the hash chain described in security.yaml#audit.
- Run commands from the executor and the debugger in a sandbox with the limits in security.yaml#sandbox.
- Account for budgets after every model and tool call and enforce them.
- Route role calls to model tiers as in agent_config.yaml#model_tiers.
- Check the kill switch at every stage boundary and before every tool call.
- Store checkpoints, state, and memory under the workspace layout in project_structure.yaml#runtime_workspace and enforce write ownership.
- Provide the approval channel and deliver user questions and status updates.

## Startup Validation

The host refuses to start unless all of the following hold.

- Every YAML file parses and has no duplicate keys.
- Every role id used in any file exists in roles.yaml.
- Every capability in a role's tool_capabilities exists in tool_use.yaml#capability_registry.
- Every reference of the form file.yaml#key resolves, and every prompt file named in the configuration exists.
- The use_for lists in agent_config.yaml#model_tiers equal the tier fields in roles.yaml.
- The used_by fields in project_structure.yaml#framework_repository match the prompt_files fields in roles.yaml.
- Every regular expression in security.yaml and quality_control.yaml compiles.

## Operating a Run

1. Start a run with the user's request. The host sets the run mode and the autonomy level.
2. PRAXIS analyzes the request, plans, and works in verified vertical slices. It asks the user only under autonomy.yaml#ask_user_policy.
3. Status updates follow autonomy.yaml#check_in_policy and report verified progress only.
4. Approvals for R3 outside policy and for R4 actions arrive through the approval channel. Silence counts as denial.
5. The run ends in COMPLETED after gate G5_delivery_ready, or in SAFE_STOPPED with a handover. Read .praxis/reports/delivery-report.md or the safe-stop report, and .praxis/handover/HANDOVER.md.
6. To resume after a stop, start a new run. It recovers from the latest checkpoint and the handover (master_agent.yaml#run_lifecycle).
7. To stop immediately, create the file .praxis/KILL or set PRAXIS_KILL to 1.

## Shared Vocabulary

- Evidence classes: VERIFIED_FACT, EVIDENCE_SUPPORTED_CONCLUSION, ASSUMPTION, HYPOTHESIS, UNKNOWN, NOT_RUN.
- Verdicts: PASS, FAIL, PARTIAL, BLOCKED, NOT_RUN. NOT_RUN is never PASS.
- Risk tiers: R0 observe, R1 scratch, R2 workspace change, R3 environment or network, R4 irreversible or external.
- Complexity classes: C0 trivial, C1 simple, C2 moderate, C3 complex, C4 extensive.
- Gates: G1_plan_approved, G2_task_accepted, G3_change_ready, G4_milestone_accepted, G5_delivery_ready.
- Severity: blocker, major, minor, nit for findings. SEV1 to SEV4 for errors and incidents.

## Change Control

- Treat this repository as versioned configuration. Change the version number and keep a changelog entry for every change.
- Never edit prompts or configuration during a run. The agent may propose changes through reflection.yaml#prompt_improvement_governance, and an operator applies accepted changes between runs.
- Changes to system_prompt.md safety invariants, security.yaml, the hard stops, or the verification independence rules require a security review before they are applied.
- After any change, repeat the startup validation.
